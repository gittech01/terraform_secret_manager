from print import imprimir

def hello(event, context):
    
    imprimir('Olá Edson')